import 'package:flutter/material.dart';
import 'package:flutter_crud_api_sample_app/src/app.dart';

void main() => runApp(App());
